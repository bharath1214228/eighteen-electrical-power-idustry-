
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta name="title" content="NEEPCO  | SWACHH VIDYALAYA ABHIYAAN">
<meta name="description" content="NEEPCO - SWACHH VIDYALAYA ABHIYAAN">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">



<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="images/favicon.ico">
<title>NEEPCO - SWACHH VIDYALAYA ABHIYAAN</title>

<link rel="stylesheet" id="vc-mm-css" href="css_version2/vc-mm-new2.css" type="text/css" media="all">
<link rel="alternate stylesheet" type="text/css" media="screen" title="black-theme" href="css_version2/black-new.css" />
<link rel="alternate stylesheet" type="text/css" media="screen" title="bigger" href="css_version2/css_bigge.css" />
<link rel="alternate stylesheet" type="text/css" media="screen" title="small" href="css_version2/css_small.css" />
	
<link rel="alternate" type="application/rss+xml" title="NEEPCO  RSS" href="https://demositeslive.com/neepcolive//rss.xml" />

<!--<style type="text/css" media="all">
@import url("css_version2/bootstrap.min.css?q54jcg");
@import url("css_version2/fonts.css?q54jcg");
@import url("css_version2/font-awesome.min.css?q54jcg");
@import url("css_version2/owl.carousel.min.css?q54jcg");
@import url("css_version2/owl.theme.default.min.css?q54jcg");
@import url("css_version2/easy-responsive-tabs.css?q54jcg");
@import url("css_version2/style-new2.css?q54jcg");
@import url("css_version2/vc-mm-new2.css?q54jcg");
@import url("css_version2/responsive-new2.css?q54jcg");
</style>-->

<link href="css_version2/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">

<link href="css_version2/fonts.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/owl.carousel.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/owl.theme.default.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/style-new2.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/vc-mm-new2.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/responsive-new2.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/liMarquee.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/endlessRiver.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/cubeportfolio.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/gallery.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/jquery.fancybox.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css_version2/site_map.theme.css" rel="stylesheet" type="text/css" media="all">

<link rel="stylesheet" type="text/css" href="css_version2/print.css" media="print" />
<link rel="stylesheet" type="text/css" href="css_version2/response3.css" media="only screen" />

<!--[if lte IE 7]>
<link type="text/css" rel="stylesheet" href="css/ie.css?q54jcg" media="all" />
<![endif]-->

<!--[if IE 6]>
<link type="text/css" rel="stylesheet" href="css/ie6.css?q54jcg" media="all" />
<![endif]-->

</head>
<body class="html front not-logged-in one-sidebar sidebar-first page-node i18n-en">
<link rel="alternate stylesheet" type="text/css" media="screen" title="bigger" href="css_version2/css_bigge.css" />
<link rel="alternate stylesheet" type="text/css" media="screen" title="small" href="css_version2/css_small.css" />

<header class="site_header header clearfix">
			<div class="top_link header_top">
				<div class="container">
					<!--<div class="hd_stock">
						<div class="quote_tit"><span></span></div>
						<div class="quote_cont">
						 
						</div>
					</div>-->
					<div class="top_link_menu text-right">
					    <div class="imp_link top_list">
							<a href="#skiptomaincontent" title="Skip to Main Content">Skip to Main Content</a>
						
						</div>
						<div class="imp_link top_list">
							<a href="important_link.php" title="Important Links">Important Links</a>
						
						</div>
						<div class="smap_link top_list">
							<a href="sitemap.php" title="Site Map">Site Map</a>
						</div>
						<div class="p_link top_list">
							 <a href="javascript:void(0)" title="Opens in a new window" id="print_val" class="print1" onClick="PrintDoc();" >Print</a>
						</div>
						<div class="sr_link top_list">
							<a href="screenreader.php" title="Screen Reader">Screen Reader</a>
						</div>
						<div class="font_link top_list">
							<ul>
								<li>
									<a href="javascript:chooseStyle('small', 60);" class="sm_text" title="Smaller Size">-A</a>
								</li>
								<li>
									<a href="javascript:chooseStyle('none', 60);" title="Default Size">A</a>
								</li>
								<li>
									<a href="javascript:chooseStyle('bigger', 60);" class="big_text" title="Bigger Size">A+</a>
								</li>
							</ul>
						</div>
						<div class="site_social soc_to_left to_social_links">
							<ul>
								<li class="face">
									<a href="https://www.facebook.com/NEEPCOIndia" target="_blank" title="Opens in a new window"><span class="fa fa-facebook"></span></a>
								</li>
								<li class="twit">
									<a href="https://twitter.com/search?q=NEEPCOINDIA" target="_blank" title="Opens in a new window"><span class="fa fa-twitter"></span></a>
								</li>
								<li class="yout">
									<a href="https://www.youtube.com/channel/UCcoSJQg7UJLLYGBxJkiNu_g" target="_blank" title="Opens in a new window"><span class="fa fa-youtube-play"></span></a>
								</li>
							</ul>
						</div>
						<div class="color_link top_list">
							<ul>
								<li class="color_one">
									<a href="javascript:chooseStyle('none', 60)" ></a>
								</li>
								<li class="color_two">
									<a href="javascript:chooseStyle('black-theme', 60)"></a>
								</li>								
							</ul>
						</div>
						<!--<div class="lang_link top_list">
							<ul class="language-switcher-locale-url"><li class="en first active"><a href="/neepcolive//" class="language-link active" xml:lang="en">English</a></li>
							<li class="hi last"><a href="/neepcolive//hi" class="language-link" xml:lang="hi">हिन्दी</a></li>
							</ul>
						</div>

						<div class="search_link top_list top_search_block">
							<a href="#" class="fa fa-search click_search"></a>
							<div class="search_block text-right">
								<form class="top_search" method="search" action="#">
									<input type="text" name="search" placeholder="Search" value="" onkeypress="handle(event)" id="srch" autocomplete="off">
									<button type="button" class="search_btn" onclick="return serach_content();">
										<span class="fa fa-search" aria-hidden="true"></span>
									</button>
								</form>
							</div>
						</div>-->
					</div>
				</div>
			</div>
			<div class="stick_header clearfix">
				<div class="top_logo">
					<div class="container">
						<div class="row">
						
							<!--<div class="col-md-9 col-sm-9 logobox">
                                <div class="logo">
                                    <a href="index.php" title="SWACHH VIDYALAYA ABHIYAAN" ><img src="images/neepco.png" alt="Neepco" /></a>
                                </div>
                                <div class="cname">
                                    <a href="index.php" title="SWACHH VIDYALAYA ABHIYAAN"><img src="images/cname.png" alt="Neepco" /></a>
                                </div>
                            </div>-->
							
							<div class="col-md-6 col-sm-6 col-xs-6 logo_header">
								<h1 class="logo">
										<a href="index.php">
										<img src="images/logonew.png" alt="SWACHH VIDYALAYA ABHIYAAN LOGO" title="SWACHH VIDYALAYA ABHIYAAN" class="logo_big">
										<img src="images/logonew_sm.png" alt="SWACHH VIDYALAYA ABHIYAAN SMALL LOGO" title="SWACHH VIDYALAYA ABHIYAAN" class="logo_sm">
									</a>
								</h1>
							</div>
											
						
							<!--<div class="col-md-6 col-sm-6 col-xs-6 logo_header">
							<div class="logo"><img src="images/neepco.png" alt="Neepco" /></div>
							<div class="cname"><img src="images/cname.png" alt="Neepco" /></div>-->
								<!--<h1 class="logo">
										<a href="/neepcolive//">
										<img src="images/neepco.png" alt="NEEPCO LOGO" class="logo_big">
										<img src="images/cname.png" alt="NEEPCO SMALL LOGO" class="logo_sm">
									</a>
								</h1>-->
							</div>
							
						</div>
					</div>
				</div>
			<nav class="top_menu clearfix">
			<div class="container" id="skiptomaincontent">
				<div class=" vc-mm-menu-h  vc-mm-h-layout-2 vc-mm-container">
					<ul class="vc-nav-on-mobile vc-mm-menu">
						<li class="vc-menu-item vc-mm-mobile-toggle">
							<a href="#" class="nav-link vc-mm-mobile-toggle-btn"> <i class="fa fa-bars"></i> </a>
						</li>
					</ul>
					<ul class="vc-nav-on-desktop vc-mm-menu">
						<li class="vc-menu-item vc-mm-mobile-toggle">
							<a href="#" class="nav-link vc-mm-mobile-toggle-btn"><i class="fa fa-bars"></i></a>
							<h3 class="vc-mm-child-title lv-0">NEEPCO<a class="vc-close" href="#"></a></h3>
						</li>
						
						
						<li class="menu-item vc-menu-item current-menu-ancestor current-menu-parent vc-d-0 ">
							<a href="index.php" class="nav-link"><span class="fa fa-home"></span>Index</a>
						</li>
						
						
						<li class="menu-item  vc-menu-item  vc-d-0 ">
								<a href="survey_team.php" class="nav-link">SVA Team</a>	
							<!--<div class='sub-menu'>
								<ul class="sub-menu-inner menu_listlarge">	  
										<li class="vc-menu-item ">
											<a href="/neepcolive//about-us/company-profile" class="nav-link" target="_self">Company Profile</a> 
										</li>
								</ul>
							</div>-->
						</li>
						
						<li class="menu-item vc-menu-item  vc-d-0 ">
								<a href="school_detail.php" class="nav-link">School detail</a>
	
						</li>
						<li class="menu-item vc-menu-item  vc-d-0 ">
								<a href="survey_detail.php" class="nav-link">Survey detail</a>
	
						</li>
						<li class="menu-item  vc-menu-item  vc-d-0 ">
								<a href="imp_detail.php" class="nav-link">Implementation Detail</a>
						</li>
						<li class="menu-item vc-menu-item  vc-d-0 ">
								<a href="summary.php" class="nav-link">SVA Summary</a>
	
						</li>
						<li class="menu-item vc-menu-item  vc-d-0 ">
								<a href="imp_summary.php" class="nav-link">Complete Toilet Report</a>
						</li>
						   <li class="menu-item vc-menu-item vc-d-0">
								<a href="admin/login.php" class="nav-link">login</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		
		
		</header>
		
<script>
function PrintDoc() {
       var toPrint = document.getElementById('midcolumn');
       var popupWin = window.open('', '_blank', '');
       popupWin.document.open();       
       popupWin.document.write('<html><title>Neepco</title><link type="text/css" href="http://demositeslive.com/swachhbharat/css_version2/style-new2.css" rel="stylesheet"  media="all" title="normal"/><link type="text/css" href="http://demositeslive.com/swachhbharat/css_version2/bootstrap.min.css" rel="stylesheet"  media="all" title="normal"/> <link type="text/css" href="http://demositeslive.com/swachhbharat/css/inner.css" rel="stylesheet"  media="all" title="normal"  /><link type="text/css" href="http://demositeslive.com/swachhbharat/css_version2/jquery-ui.css" rel="stylesheet" /><link type="text/css" href="http://demositeslive.com/swachhbharat/css/ticker-style.css" rel="stylesheet"  /><link type="text/css" rel="stylesheet" href="http://demositeslive.com/swachhbharat/css/colorbox.css" /><link type="text/css" rel="stylesheet" href="http://demositeslive.com/swachhbharat/css/jquery.lightbox-0.5.css" media="screen" /><style>html { overflow-x: hidden;overflow-y: auto;}#example-one .nav{height:auto;}.breadCrumb {margin-bottom: 5px;}</style></head><body class="print_page">');
       popupWin.document.write('<div class="printIcons" style="float:none;"><a title="Opens in a new window" id="printer" class="print1" onClick="getElementById(\'printer\').style.display = \'none\';window.print();">Print</a></div>');
       popupWin.document.write(toPrint.innerHTML);
       popupWin.document.write('</html>');
       popupWin.document.close();
   }
</script>					<div id="features" class="bread-crumbs">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<div class="features features-main triggerAnimation animated" data-animate="fadeInUp">
									<div class="header">
										<h2>SWACHH VIDYALAYA ABHIYAAN</h2>										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Features End -->
				<div class="clearfix"></div>				
				<!-- #Our Doctor -->
				<div id="our-doctor">
					<div class="container" id="midcolumn">						
							<div class="row prog-tech stats">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="doctor-main triggerAnimation animated" data-animate="fadeInUp">
                                            <div class="header">
                                                <h3>STATUS SUMMARY</h3>
                                                <span><a class="view" href="summary.php" target="blank"> View More Details <i class="fa fa-angle-double-right"></i></a></span>
                                            </div>								
                                            <div class="col-md-4 col-sm-12 col-xs-12">
                                                <div class="member">
                                                    <div class="sub-header">
                                                        <h5>Identified  Nos. Of Toilets To Be Built As Per MHRD</h5>
                                                        <div class="digit">664</div>
                                                    </div>                                               
                                                    
                                                </div>
                                             
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-12 col-xs-12">
                                                <div class="memberet">
                                                    <div class="sub-header">
                                                        <h5>Total Nos. Of Schools As Per MHRD Confirmed List</h5>
                                                        <div class="digit">387</div>
                                                    </div>                                                   
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-4 col-sm-12 col-xs-12">
                                                <div class="memberet">
                                                    <div class="sub-header">
                                                        <h5>Total Nos. Of Targeted Toilets</h5>
                                                        <div class="digit">664</div>
                                                    </div>                                                    
                                                </div>
                                            </div>
                                            
                                            
                                        </div>            
                                    </div>

                                    <!--<div class="col-md-3 col-sm-6 col-xs-12 right-panel">
                                        <div class="doctor-main triggerAnimation animated" data-animate="fadeInUp">
                                            <div class="header">
                                                <h3>CMD's Message</h3>
                                                <span><a class="view" href="#" target="blank"> View all Technology<i class="fa fa-angle-double-right"></i></a></span>
                                            </div>	
                                            <div class="col-md-12 col-xs-12">
                                                <div class="memberet cmdbox">
                                                    <div class="sub-header">
                                                    	<img src="images/bod/CPankaj1.jpg" width="80" alt="Shri P C Pankaj" />
                                                        <h6 class="cmd">Shri P C Pankaj</h6>
                                                        <h6>CMD NEEPCO Ltd.</h6>
                                                        <p>Donec tellus massa, tristique sit amet condimentum vel, facilisis quis sapien. Praesent id enim .</p>
                                                    
                                                    <div class="btn-section">
                                                            <a class="btn btn-primary" href="#" role="button" target="blank">View Detail</a>
                                                    </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        
                                            <div class="col-md-12 col-xs-12">
                                                <div class="memberet">
                                                    <figure>
                                                        <img src="images/member-pic.jpg" class="img-responsive" alt="Responsive image">
                                                    </figure>
                                                    <div class="sub-header">
                                                        <h5>Other Events</h5>
                                                        <p>Donec tellus massa</p>
                                                        <p>Donec tellus massa, tristique sit amet condimentum vel, facilisis quis sapien. Praesent id enim .</p>
                                                        <div class="btn-section">
                                                            <a class="btn btn-primary" href="#" role="button" target="blank">View Detail</a>
                                                    	</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>--><!--Row End -->
                <div class="gal-scroll col-md-12 col-sm-12 col-xs-12"> 
                                            <div class="header">
                                                 <h3>PHOTO GALLERY</h3>   
                                            </div>                                               
                                                <div class="memberet">                                                	
                                                    <div class="sub-header">                                                        
                                                        <div id="carousel">
                                                                                                                         <div>
                                                             	<a class='sample' data-lighter='images/gallery/big/AGTP-1.jpg' data-width='800' href='images/gallery/big/AGTP-1.jpg'>
                                                                <img src="images/gallery/AGTP-1.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             	<a class='sample' data-lighter='images/gallery/big/AGTP-2.jpg' data-width='800' href='images/gallery/big/AGTP-2.jpg'>
                                                                <img src="images/gallery/AGTP-2.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/AGTP-3.jpg' data-width='800' href='images/gallery/big/AGTP-3.jpg'>
                                                                <img src="images/gallery/AGTP-3.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/AGTP-4.jpg' data-width='800' href='images/gallery/big/AGTP-4.jpg'>
                                                                <img src="images/gallery/AGTP-4.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/AGTP-5.jpg' data-width='800' href='images/gallery/big/AGTP-5.jpg'>
                                                                <img src="images/gallery/AGTP-5.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/AGTP-6.jpg' data-width='800' href='images/gallery/big/AGTP-6.jpg'>
                                                                <img src="images/gallery/AGTP-6.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/Balat-3.jpg' data-width='800' href='images/gallery/big/Balat-3.jpg'>
                                                                <img src="images/gallery/Balat-3.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/Balat-5.jpg' data-width='800' href='images/gallery/big/Balat-5.jpg'>
                                                                <img src="images/gallery/Balat-5.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/desc1.jpg' data-width='800' href='images/gallery/big/desc1.jpg'>
                                                                <img src="images/gallery/desc1.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/desc2.jpg' data-width='800' href='images/gallery/big/desc2.jpg'>
                                                                <img src="images/gallery/desc2.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/desc3.jpg' data-width='800' href='images/gallery/big/desc3.jpg'>
                                                                <img src="images/gallery/desc3.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN" />
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/Handing-over.jpg' data-width='800' href='images/gallery/big/Handing-over.jpg'>
                                                                <img src="images/gallery/Handing-over.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/Handing-over-2.jpg' data-width='800' href='images/gallery/big/Handing-over-2.jpg'>
                                                                <img src="images/gallery/Handing-over-2.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/Handing-over-3.jpg' data-width='800' href='images/gallery/big/Handing-over-3.jpg'>
                                                                <img src="images/gallery/Handing-over-3.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/innogoration.jpg' data-width='800' href='images/gallery/big/innogoration.jpg'>
                                                                <img src="images/gallery/innogoration.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/Plastering-painting.jpg' data-width='800' href='images/gallery/big/Plastering-painting.jpg'>
                                                                <img src="images/gallery/Plastering-painting.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>
                                                            <div>
                                                            <a class='sample' data-lighter='images/gallery/big/Plinth-coloumn.jpg' data-width='800' href='images/gallery/big/Plinth-coloumn.jpg'>
                                                                <img src="images/gallery/Plinth-coloumn.jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>  
                                                             <div>
                                                             <a class='sample' data-lighter='images/gallery/big/UMLANGMAR-(3).jpg' data-width='800' href='images/gallery/big/UMLANGMAR-(3).jpg'>
                                                                <img src="images/gallery/UMLANGMAR-(3).jpg" alt="SWACHH VIDYALAYA ABHIYAAN" title="SWACHH VIDYALAYA ABHIYAAN"/>
                                                                </a>
                                                                <!--<span>Melon</span>-->
                                                            </div>                                                                                                                    
                                                        </div>                                                     
                                                    </div>                                                    
                                                </div>
                                            </div>
							</div>
					</div>
                </div>
				<div class="clearfix"></div>
				
<footer class="main_footer clearfix">
	<div class="top_footer">
		<div class="container">
			<div class="row">
				<div class="foot_link col-md-2 col-sm-4">
					<ul>					
						<li><a href="index.php" class="nav-link" target="_self" title="Index">Index</a></li>	
						<li><a href="survey_team.php" class="nav-link" target="_self" title="SVA Team">SVA Team</a></li>													
					</ul>
				</div>
				<div class="foot_link col-md-2 col-sm-4">
					<ul>
						<li><a href="school_detail.php" class="nav-link" target="_self" title="School Detail">School detail</a></li>
						<li><a href="survey_detail.php" class="nav-link" target="_self" title="Survey Detail">Survey detail</a></li>													
					</ul>
				</div>
				<div class="foot_link col-md-2 col-sm-3">
					<ul>	
						<li><a href="imp_detail.php" class="nav-link" target="_self" title="Implementation Detail">Implementation Detail</a></li>
						<li><a href="summary.php" class="nav-link" target="_self" title="SVA Summary">SVA Summary</a></li>						
					</ul>
				</div>
				<div class="foot_link col-md-2 col-sm-3">
					<ul>					
						<li><a href="imp_summary.php" class="nav-link" target="_self" title="Complete Toilet Report">Complete Toilet Report</a></li>						
						<li><a href="admin/login.php" class="nav-link" target="_self" title="Login">login</a></li>		
					</ul>
				</div>				
				<!--<div class="foot_link col-md-2 col-sm-3">
					<ul>
					<li><a href="websitepolicy.php" target="_blank" title="Website Policies">Website Policies</a></li>
					<li><a href="websitedisclaimer.php" title="Disclaimer">Disclaimer</a></li>
					<li><a href="privacy.php" title="Privacy Statement">Privacy Statement</a></li>
					</ul>
				</div>-->
				
				<div class="foot_link web_foot_link">
					<ul>
					<li><a href="websitepolicy.php" target="_blank" title="Website Policies">Website Policies</a></li>
					<li><a href="websitedisclaimer.php" title="Disclaimer">Disclaimer</a></li>
					<li><a href="privacy.php" title="Privacy Statement">Privacy Statement</a></li>
					</ul>
					<div style="float: right;">
						<a title="PDF, Open in New Window" href="https://neepco.co.in/sites/default/files/neepco-stqc.pdf" target="_blank">
						<img src="https://neepco.co.in/sites/default/files/cqw_logo.png"></a>
					</div>
				</div>
				
				<div class="foot_link visitor_count">
					<p>ISO 9001,ISO 14001 and ISO 45001</p>
					<!--<p class="number_upd"><span>No. of Visitors: </span>725588</p>-->
					<p class="number_upd"><span>Last Updated: </span>26/06/2020</p>
				</div>
				</div>

			</div>
		</div>
		<div class="copy_footer">
				<div class="container">
				<p class="copy_cont">Copyright © 2017 North Eastern Electric Power Corporation Ltd.</p>
			</div>
		</div>
</footer>
		<!--<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>-->
		
		<script src="js/jquery.minv-1.12.js"></script>
		<script src="js/news-scroller.js"></script>		
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/tabs.js"></script>
		<script src="js/easyResponsiveTabs.js"></script>		
		<script src="js/styleswitch.js"></script>
		<script src="js/common.js"></script>
		<script src="js/vc-mm.js"></script>
		<script src="js/endlessRiver.js"></script>
		<script src="js/crawler.js"></script>
		
		<script src="js/jquery.cubeportfolio.min.js"></script>
		<script src="js/protfolio_main.js"></script>
		<script src="js/gallery/modernizr.custom.97074.js"></script>
		<script src="js/gallery/lightgallery.min.js"></script>
		<script src="js/gallery/lg-fullscreen.min.js"></script>
		<script src="js/gallery/lg-thumbnail.min.js"></script>
		<script src="js/gallery/lg-video.min.js"></script>
		<script src="js/gallery/lg-autoplay.min.js"></script>
		<script src="js/gallery/lg-zoom.min.js"></script>		
		<script src="js/gallery/lg-hash.min.js"></script>
		<script src="js/gallery/lg-pager.min.js"></script>
		<script src="js/gallery/jquery.mousewheel.min.js"></script>
		<script src="js/gallery/jquery.hoverdir.js"></script>
		<script src="js/gallery/jquery.fs.boxer.js"></script>
		<script src="js/smk-accordion.js"></script>
		<script src="js/jquery.fancybox.min.js"></script>
		
		
		
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.stickem.js"></script>
        <script src="js/jquery.carouFredSel-6.0.4-packed.js" ></script>
        
        <script src="js/custom.js"></script>
		<script src='js/jquery.lighter.js' ></script>
		<link href='css/jquery.lighter.css' rel='stylesheet' type='text/css'>

</body>
</html>
